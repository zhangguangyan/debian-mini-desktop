
package com.example.eligibility.dsl

import com.example.eligibility.model.*

@DslMarker
annotation class EligibilityDsl

class RuleSetBuilder(private val name: String) {
    private val rules = mutableListOf<EligibilityRule>()

    fun rule(id: String, block: RuleBuilder.() -> Unit) {
        val builder = RuleBuilder(id)
        builder.block()
        rules += builder.build()
    }

    fun build() = RuleSet(name, rules)
}

class RuleBuilder(private val id: String) {
    var description: String? = null
    var productCode: String? = null
    var priority: Int = 100

    private var condition: (EligibilityContext) -> Boolean = { true }
    private var outcome: (EligibilityContext) -> RuleOutcome = { RuleOutcome.Ineligible("No outcome") }

    fun when_(block: EligibilityContext.() -> Boolean) {
        condition = block
    }

    fun then(block: OutcomeBuilder.() -> RuleOutcome) {
        outcome = { ctx -> OutcomeBuilder(ctx).block() }
    }

    fun build() =
        EligibilityRule(id, description, productCode, priority, condition, outcome)
}

class OutcomeBuilder(private val ctx: EligibilityContext) {
    val customer get() = ctx.customer
    val product get() = ctx.product

    fun eligible(reason: String, limit: Int? = null, segment: String? = null) =
        RuleOutcome.Eligible(reason, limit, segment)

    fun ineligible(reason: String) = RuleOutcome.Ineligible(reason)

    fun manualReview(reason: String, queue: String? = null) =
        RuleOutcome.ManualReview(reason, queue)
}

fun eligibilityRules(name: String, block: RuleSetBuilder.() -> Unit): RuleSet =
    RuleSetBuilder(name).apply(block).build()

data class RuleSet(val name: String, val rules: List<EligibilityRule>)
