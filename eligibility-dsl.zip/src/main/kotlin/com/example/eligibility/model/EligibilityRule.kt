
package com.example.eligibility.model

data class EligibilityRule(
    val id: String,
    val description: String?,
    val productCode: String?,
    val priority: Int,
    val condition: (EligibilityContext) -> Boolean,
    val outcome: (EligibilityContext) -> RuleOutcome
)
