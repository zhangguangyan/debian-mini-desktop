
package com.example.eligibility

import com.example.eligibility.dsl.*
import com.example.eligibility.model.*
import org.junit.jupiter.api.Test
import kotlin.test.assertTrue

class EligibilityEngineTest {
    @Test
    fun `under 18 should be ineligible`() {
        val rules = eligibilityRules("credit") {
            rule("UNDER_18") {
                when_ { customer.age < 18 }
                then { ineligible("Under 18") }
            }
        }

        val ctx = EligibilityContext(
            Customer("C1", 16, "AU", 2000, RiskSegment.LOW),
            Product("CC_GOLD", "CREDIT_CARD"),
            "ONLINE"
        )

        val engine = EligibilityEngine(rules)
        val result = engine.firstHit(ctx)

        assertTrue(result is RuleOutcome.Ineligible)
    }
}
