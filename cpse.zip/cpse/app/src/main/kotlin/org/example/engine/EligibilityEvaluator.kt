package org.example.engine

import org.example.core.BaseContext
import org.example.core.Enrich
import org.example.core.Rule
import org.example.model.Customer

fun evaluateRules(ruleName: String, properties: Map<String, String>): Boolean {
    // Load Rule class dynamically
    val ruleClass = Class.forName(ruleName).kotlin
    val constructor = ruleClass.java.getConstructor(String::class.java)
    val rule = constructor.newInstance(ruleName) as Rule
    val contextName = rule.contextName()

    val contextClass = Class.forName(contextName).kotlin
    // Find fields annotated with @Enrich (including inherited fields)
    val enrichFields = mutableListOf<java.lang.reflect.Field>()
    var currentClass: Class<*>? = contextClass.java
    while (currentClass != null) {
        val fields = currentClass.declaredFields.filter { field ->
            field.isAnnotationPresent(Enrich::class.java)
        }
        enrichFields.addAll(fields)
        currentClass = currentClass.superclass
    }
    
    // call enrichment service based on enrichFields and populate context
    val customer = Customer("CUST001", 25, "AU", 5000, null)
    println("\nCustomer created: $customer")
    System.out.flush()

    val contextConstructor = contextClass.java.getConstructor(String::class.java)
    val context = contextConstructor.newInstance("RuleContext-MyRule")
    
    println("Enrich fields: ${enrichFields.map { it.name }}")
    enrichFields.forEach { field ->
        println("Enriching field: ${field.name}")
        field.isAccessible = true
        if (field.type == Customer::class.java) {
            // Assign customer to @Enrich fields
            field.set(context, customer)
        }
    }
    
    return rule.evaluate(context as BaseContext)
}
