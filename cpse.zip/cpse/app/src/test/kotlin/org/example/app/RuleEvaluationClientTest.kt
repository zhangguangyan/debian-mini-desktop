/*
 * gRPC Client Integration Test for the Rule Evaluation Service
 * 
 * Prerequisites: Start the gRPC server before running this test:
 *   ./gradlew :app:run
 */
package org.example.app

import io.grpc.ManagedChannelBuilder
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Tag
import java.util.concurrent.TimeUnit
import io.grpc.StatusRuntimeException
import org.junit.jupiter.api.Assumptions.assumeTrue

@Tag("integration")
class RuleEvaluationClientTest {
    
    private lateinit var channel: io.grpc.ManagedChannel
    private lateinit var stub: RuleEvaluationGrpc.RuleEvaluationBlockingStub
    
    @BeforeEach
    fun setUp() {
        channel = ManagedChannelBuilder.forAddress("localhost", 50051)
            .usePlaintext()
            .keepAliveTime(30, TimeUnit.SECONDS)
            .keepAliveTimeout(10, TimeUnit.SECONDS)
            .build()
        
        stub = RuleEvaluationGrpc.newBlockingStub(channel)
            .withDeadlineAfter(30, TimeUnit.SECONDS)
        
        // Check if server is available
        try {
            val testRequest = EvaluateRequest.newBuilder()
                .setRuleName("org.example.rules.Rule")
                .build()
            stub.withDeadlineAfter(2, TimeUnit.SECONDS).evaluate(testRequest)
        } catch (e: StatusRuntimeException) {
            assumeTrue(false, """
                |
                |==========================================
                |gRPC server is not running on localhost:50051
                |
                |To run this integration test, first start the server:
                |  ./gradlew :app:run
                |
                |Then run the test in a separate terminal:
                |  ./gradlew :app:test --tests "RuleEvaluationClientTest"
                |==========================================
                |""".trimMargin())
        }
    }
    
    @AfterEach
    fun tearDown() {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS)
    }
    
    @Test
    fun `test evaluate rule with properties`() {
        // Create a request
        val request = EvaluateRequest.newBuilder()
            .setRuleName("org.example.rules.Rule")
            .putProperties("author", "John")
            .putProperties("version", "1")
            .build()
        
        // Call the service
        val response = stub.evaluate(request)
        
        // Verify response
        assertNotNull(response, "Response should not be null")
        assertNotNull(response.message, "Response message should not be null")
        assertEquals("Rule evaluated successfully", response.message)
        
        println("Response received:")
        println("Result: ${response.result}")
        println("Message: ${response.message}")
    }
}
