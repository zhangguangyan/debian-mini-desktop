package org.example.engine

import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.*

class EligibilityEvaluatorTest {

    @Test
    fun `should successfully evaluate rule with properties`() {
        // Given
        val ruleName = "org.example.rules.rule1.Rule"
        val properties = mapOf(
            "author" to "John Doe",
            "version" to "1.0"
        )

        // When
        val result = evaluateRules(ruleName, properties)

        // Then
        assertTrue(result, "Rule should evaluate to true")
    }
}
