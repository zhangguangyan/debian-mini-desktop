package org.example.rules.rule1;

import org.example.core.BaseContext;
import org.example.model.Customer;

public class Rule implements org.example.core.Rule {
    private String name;

    public Rule(String name) {
        this.name = name;
    }

    public String contextName() {
        return org.example.rules.rule1.Context.class.getName();
    }

    public boolean prequalifyCheck(BaseContext context) {
        return true;
    }

    public boolean doEvaluate(BaseContext context) {
        var ctx = (Context) context;
        var customer = ctx.getCustomer();
        System.out.println("Evaluating rule: " + name + " with context: " + context + " and customer: " + customer);
        return true;
    }
}
