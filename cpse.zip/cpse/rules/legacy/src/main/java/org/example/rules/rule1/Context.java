package org.example.rules.rule1;

import org.example.core.BaseContext;
import org.example.core.Enrich;

public class Context extends BaseContext {
    @Enrich
    private String address;
    
    public Context(String name) {
        super(name);
    }
}
