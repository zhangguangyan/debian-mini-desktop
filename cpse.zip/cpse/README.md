# gRPC Rule Evaluation Service

A gRPC-based rule evaluation service built with Kotlin.

## Architecture

```mermaid
graph LR
    app[app]
    rules[rules]
    core[core]

    app -->|implementation| rules
    app -->|api| core
    rules -->|api| core
```

- **gRPC Server**: Listens on port 50051
- **Rule Engine**: Dynamic rule loading and evaluation
- **Enrichment**: Automatic customer data injection via `@Enrich` annotation

## Running with Docker

### Build and Run

```bash
# Build the Docker image
docker build -t grpc-rule-service .

# Run the container
docker run -p 50051:50051 grpc-rule-service
```

### Using Docker Compose

```bash
# Start the service
docker-compose up -d

# View logs
docker-compose logs -f

# Stop the service
docker-compose down
```

## Running Locally

### Start the Server

```bash
./gradlew :app:run
```

### Test with Client

```bash
./gradlew :app:runClient
```

## API

### Evaluate Rule

**Service**: `RuleEvaluation`  
**Method**: `Evaluate`

**Request**:
```protobuf
message EvaluateRequest {
  string rule_name = 1;
  string customer_id = 2;
  int32 age = 3;
  string country = 4;
  int32 income = 5;
  string context_name = 6;
  map<string, string> properties = 7;
}
```

**Response**:
```protobuf
message EvaluateResponse {
  bool result = 1;
  string message = 2;
}
```

## Development

### Build

```bash
./gradlew build
```

### Generate Protobuf

```bash
./gradlew :app:generateProto
```

### Run Tests

```bash
./gradlew test
```
