package org.example.core

interface Rule {
    fun contextName(): String
    fun prequalifyCheck(context: BaseContext): Boolean = true
    fun doEvaluate(context: BaseContext): Boolean
    
    fun evaluate(context: BaseContext): Boolean {
        if (!prequalifyCheck(context)) {
            return false
        }
        return doEvaluate(context)
    }
}
