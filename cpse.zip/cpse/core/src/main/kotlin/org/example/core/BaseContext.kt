package org.example.core

import org.example.model.Customer
import org.example.model.Product

open class BaseContext(val name: String) {
    private val properties: MutableMap<String, Any> = mutableMapOf()
    
    @field:Enrich
    var customer: Customer? = null
    var product: Product? = null
    
    fun setProperty(key: String, value: Any) {
        properties[key] = value
    }
    
    fun getProperty(key: String): Any? {
        return properties[key]
    }
    
    fun hasProperty(key: String): Boolean {
        return properties.containsKey(key)
    }
}
