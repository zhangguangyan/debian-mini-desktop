
package org.example.model

data class Customer(
    val id: String,
    val age: Int,
    val residentCountry: String,
    val incomeMonthly: Int,
    val riskSegment: RiskSegment?
)

enum class RiskSegment { LOW, MEDIUM, HIGH }

data class Product(
    val code: String,
    val category: String
)

data class EligibilityContext(
    val customer: Customer,
    val product: Product,
    val channel: String
)
