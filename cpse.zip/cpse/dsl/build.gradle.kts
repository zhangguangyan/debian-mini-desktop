/*
 * Eligibility DSL subproject
 */

plugins {
    id("buildlogic.kotlin-application-conventions")
}

dependencies {
    implementation(project(":core"))
}

application {
    // Define the main class for the application.
    mainClass = "com.example.eligibility.MainKt"
}
