
package com.example.eligibility.model

sealed class RuleOutcome {
    data class Eligible(
        val reason: String,
        val limit: Int? = null,
        val segment: String? = null
    ) : RuleOutcome()

    data class Ineligible(val reason: String) : RuleOutcome()

    data class ManualReview(
        val reason: String,
        val queue: String? = null
    ) : RuleOutcome()
}
