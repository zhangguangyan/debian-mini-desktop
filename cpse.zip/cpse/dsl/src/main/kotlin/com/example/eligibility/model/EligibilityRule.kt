
package com.example.eligibility.model

import org.example.core.BaseContext

data class EligibilityRule(
    val id: String,
    val description: String?,
    val productCode: String?,
    val priority: Int,
    val condition: (BaseContext) -> Boolean,
    val outcome: (BaseContext) -> RuleOutcome
)
