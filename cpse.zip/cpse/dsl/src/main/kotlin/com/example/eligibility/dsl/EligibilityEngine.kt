
package com.example.eligibility.dsl

import com.example.eligibility.model.*
import org.example.core.BaseContext

class EligibilityEngine(private val ruleSet: RuleSet) {

    fun firstHit(ctx: BaseContext): RuleOutcome {
        val rule = ruleSet.rules
            .sortedBy { it.priority }
            .firstOrNull { it.condition(ctx) }
            ?: return RuleOutcome.Ineligible("No matching rule")

        return rule.outcome(ctx)
    }
}
